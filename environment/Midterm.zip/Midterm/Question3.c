/*  This program asks the user to input their name, a floating point number, a day of the week, a noun, and an integer
    It then prints out a madlib-esque sentence that includes all of the above inputs as a single sentence.
*/
// AUTHOR: PUT YOUR NAME HERE
// Worth 5 points


int main(void)
{
    // TODO
}

