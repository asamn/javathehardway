/*  This program asks the user for a number between 30 and 80, verifying it is an acceptable input.
    It then uses a while loop to count from from that number to zero.
    The program only prints out every increment of 5 (i.e. 25, 20, 15, 10, 5, 0)
    When reaching zero, the program prints "0", and then prints how many times it printed a number.

    For example: If the user entered 28, the program would print:
        25
        20
        15
        10
        5
        0
        This program printed 6 numbers.

    *More points for having an efficient solution rather than a "brute force" solution*
*/
// AUTHOR: PUT YOUR NAME HERE
// Worth: 10 points


int main(void)
{
    // TODO
}