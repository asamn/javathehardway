/* A program that counts from 1 to 10 using a for loop printing each number on it's own line
      Example output:
      1
      2
      3
      ..
      10
*/
// AUTHOR: PUT YOUR NAME HERE
// Worth 5 points

#include <stdio.h>

int main(void)
{
    // TODO
}